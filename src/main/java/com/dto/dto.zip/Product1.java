package com.dto;

import java.io.Serializable;

public class Product1 implements Serializable{

	private int price;
	private String name;
	
	public Product1( String name,int price) {
		super();
		this.price = price;
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Product [price=" + price + ", name=" + name + "]";
	}
}